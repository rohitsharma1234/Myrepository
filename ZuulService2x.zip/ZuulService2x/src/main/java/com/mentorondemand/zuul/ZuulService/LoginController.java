package com.mentorondemand.zuul.ZuulService;

import org.springframework.web.bind.annotation.RequestMapping;

public class LoginController {
	@RequestMapping("/user")
    public String loginPage(){
        return "Hi";
    }
}
